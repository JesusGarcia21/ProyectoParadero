<?php
        $data = "Usted esta conectado";
        echo("<script>console.log('PHP: " . $data . "');</script>");
    ?>